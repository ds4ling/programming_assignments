fricatives
==========

## Codebook

- obs: (character), observation number
- s_cog: (numeric), center of gravity measurement in Hz for [s].
- s_skewness: (numeric), skewness measurement for [s].
- sh_cog: (numeric), center of gravity measurement in Hz for [ʃ].
- sh_skewness: (numeric), skewness measurement for [ʃ].